const express =require("express");
const path = require("path");
const app=express();
const port =80;

//for static file
app.use('/static',express.static('static'));

//set template engion as pug 
app.set('view engine','pug');

//set view directory
app.set('views',path.join(__dirname,'views'));


app.get("/", (req, res) =>{
    res.send("this is my app home page");
});


//our pug demo endpoint
app.get("/demo", (req, res) =>{
    res.status(200).render('demo',{ title:"ishu",message:"this is my app home page in demo.pug"});
});

app.get("/about", (req, res) =>{
    res.send("this is my app about page");
});

app.get("/this", (req, res) =>{
    res.status(404).send("this is not found");
});


app.listen(port,()=>{
    console.log(`Server running at http://localhost:${port}/`);
})

