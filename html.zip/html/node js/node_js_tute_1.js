// const fs =require('fs');
// let text=fs.readFileSync("ishu.txt","utf-8");

// //text =text.replace()

// console.log("the content of the file is")
// console.log(text)



//////////////////////////////

const http = require('http');

const hostname = '127.0.0.1';
const port = 3000;

const fs =require('fs');
const fileconst=fs.readFileSync("ishu.txt","utf-8");

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/html');
  res.end(fileconst );
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});